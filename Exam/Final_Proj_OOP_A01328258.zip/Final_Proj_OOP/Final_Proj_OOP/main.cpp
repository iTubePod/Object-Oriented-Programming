#include "Bank.h"

int main()
{
	Bank *B = new Bank();
}