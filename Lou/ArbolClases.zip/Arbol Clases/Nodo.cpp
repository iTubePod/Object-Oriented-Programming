//  Nodo.cpp

#include "Nodo.h"
Nodo::Nodo()
{
    dato = "";
    hijoDer = NULL;
    hijoIzq = NULL;
    pa = NULL;
}
string 		Nodo::getDato(){    return dato;	}
Nodo * 		Nodo::getHijoDer(){    return hijoDer;	}
Nodo * 		Nodo::getHijoIzq(){    return hijoIzq;	}
Nodo * 		Nodo::getPa(){    return pa;	}
void 		Nodo::setDato(string d){    dato = d;	}

Nodo * 		Nodo::setHijoDer(Nodo *hd){
	hijoDer = hd;
	hd->setPa(this);
	return hd;
}
Nodo * 		Nodo::setHijoIzq(Nodo *hi){    
	hijoIzq = hi;
	hi->setPa(this);
	return hi;
}
void 		Nodo::setPa(Nodo *p){	pa = p;}
Nodo * 		Nodo::setPa(Nodo *p, int lado){
	pa = p;
	if (lado == 0)
		p->setHijoDer(this);
	if (lado == 1)
		p->setHijoIzq(this);
	return p;
}
