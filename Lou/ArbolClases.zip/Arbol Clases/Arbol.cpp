//  Arbol.cpp

#include "Arbol.h"

Arbol::Arbol(){    raiz = NULL;   }
Arbol::Arbol(Nodo * r){	raiz = r;	}

void Arbol::arbolPrueba(){
	
    Nodo *a = new Nodo();
    a->setDato("A");
    Nodo *b = new Nodo();
    b->setDato("B");
    Nodo *c = new Nodo();
    c->setDato("C");
    Nodo *d = new Nodo();
    d->setDato("D");
    Nodo *e = new Nodo();
    e->setDato("E");
    
    a = a->setHijoDer(b);
    a = a->setHijoIzq(c);
    
    c = c->setHijoDer(d);
    c = c->setHijoIzq(e);
    
    raiz = a;
}

void Arbol::armaLaberinto(){
	Nodo * camino[13];
	for(int i = 0; i < 13; i++){
		camino[i] = new Nodo();
		camino[i]->setDato(to_string(i));
	}
	
}

void Arbol::postOrden(Nodo *v){
    if( v == NULL)
        return;
    
    postOrden(v->getHijoIzq());
    postOrden(v->getHijoDer());
    cout<<v->getDato()<<", ";
}

void Arbol::preOrden(Nodo *v){
    if( v == NULL)
        return;
    cout<<v->getDato()<<", ";
    preOrden(v->getHijoIzq());
    preOrden(v->getHijoDer());
}

void Arbol::inOrden(Nodo *v){
    if( v == NULL)
        return;
    inOrden(v->getHijoIzq());
    cout<<v->getDato()<<", ";
    inOrden(v->getHijoDer());
}

void Arbol::imprimeRuta(Nodo *n){
	Nodo * temp = n;
	do{
		cout<<n->getDato()<<", ";
		temp = temp->getPa();
	}while(temp->getPa() != NULL);
}

bool Arbol::esHoja(Nodo *v){
	if(v->getHijoDer() || v->getHijoIzq())
		return false;
	else
		return true;
}

int Arbol::profundidad(Nodo *v){
	int p = 0;
	while(!(v->getPa())){
		p++;
		v = v->getPa();
	}
	return p;
}

int Arbol::altura(Nodo *v){
	if(esHoja(v)){
		return 0;
	}else{
		if(altura(v->getHijoDer()) > altura(v-> getHijoIzq()))
			return altura(v->getHijoDer()) + 1;
		else
			return altura(v->getHijoIzq()) + 1;
	}
}

Nodo * Arbol::getRaiz(){    return raiz;}

/*
void Arbol::busca(Nodo *n, int x){
	if(n == NULL)
        return;
    busca(n->getHijoIzq());
    busca(n->getHijoDer());
    if(n->getDato() == x){
		n = n->getPa();
		cout<<n->getDato()<<", ";
	}
}
*/
