//  Arbol.h

#include "Nodo.h"
#include <iostream>
#include <string>

using namespace std;

class Arbol {
    
private:
    Nodo *raiz;
public:
    Arbol();
    Arbol(Nodo * r);
    void arbolPrueba();
    void armaLaberinto();
    void postOrden(Nodo *v);
    void preOrden(Nodo *v);
    void inOrden(Nodo *v);
    bool esHoja(Nodo *v);
    int profundidad(Nodo *v);
    int altura(Nodo *v);
    void busca(Nodo * n, int x);
    
    Nodo *getRaiz();
    void imprimeRuta(Nodo *n);
};
