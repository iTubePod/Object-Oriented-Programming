
#include <iostream>
#include <string>

using namespace std;

class Nodo {
    
private:
    string dato;
    Nodo *hijoDer;
    Nodo *hijoIzq;
    Nodo *pa;
    
public:
    Nodo();
    string getDato();
    void setDato(string d);
    Nodo * getHijoDer();
    Nodo * setHijoDer(Nodo *hd);
    Nodo * getHijoIzq();
    Nodo * setHijoIzq(Nodo *hi);
    Nodo * getPa();
    void setPa(Nodo *p);
    Nodo * setPa(Nodo *p, int lado);
};
