//
//  main.cpp
//  ArbolNodo
//
//  Created by LourdesMG on 3/1/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include "Arbol.h"

int main (int argc, const char * argv[])
{
    Arbol *tree = new Arbol();
    tree->arbolPrueba();
    tree->postOrden(tree->getRaiz());
    tree->imprimeRuta(tree->getRaiz()->getHijoIzq()->getHijoDer());
    
    
    cout<<"\n";
    
        
    int x;
    cin>>x;
    return 0;
}

